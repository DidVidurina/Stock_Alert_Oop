import requests
from datetime import datetime, timedelta, date


class News_Logic():

    def __init__(self):
        super().__init__()
        self.yesterdays_date = str(date.today() - timedelta(1))
        self.NEWS_ENDPOINT = "https://newsapi.org/v2/everything"
        self.NEWS_API_KEY = "640a2a457e92486995c222883817d703"
        self.URL = (f"https://newsapi.org/v2/everything?q=Tesla Inc&desctiption&from={self.yesterdays_date}"
                    f"&sortBy=popularity&apiKey={self.NEWS_API_KEY}")
        self.response = (requests.get(self.URL)).json()
        self.article = ""
        self.article_list = []
        self.assembled_text = ""

    def assemble_text(self):
        self.article_counter = 0
        for item in range(3):
            self.article = f"{self.response['articles'][self.article_counter]['title']}\nSource: {self.response['articles'][self.article_counter]['author']}\nUrl: {self.response['articles'][self.article_counter]['url']}"
            self.article_list.append(self.article)
            self.article_counter += 1
        self.article_counter = 0
        self.assembled_text = f"Your stock has seen a high price change, here are the news articles: \n\n{self.article_list[0]}\n\n{self.article_list[1]}\n\n{self.article_list[2]}"