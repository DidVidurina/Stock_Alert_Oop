import requests
from datetime import datetime, timedelta, date
import os
from twilio.rest import Client
ACCOUNT_SID = "ACc0731262064b69a0ced65e107ba33905"
AUTH_TOKEN = "a0fc7841391e4e48905cf0d60493f370"



class Message_Sender():

    def __init__(self):
        super().__init__()
        self.client = Client(ACCOUNT_SID, AUTH_TOKEN)


    def send_message(self,message):
        self.message = self.client.messages.create(
            body=f"{message}",
            from_="+12762658080",
            to="+447899771405")
