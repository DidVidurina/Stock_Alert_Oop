from stock_logic import Stock_Logic
from news_logic import News_Logic
from message_sender import Message_Sender

sl = Stock_Logic()
nl = News_Logic()
ms = Message_Sender()

sl.percentage_calc()
if float(sl.percentage) > 4.99:
    nl.assemble_text()
    ms.send_message(nl.assembled_text)
















































