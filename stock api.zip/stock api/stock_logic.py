import requests
from datetime import datetime, timedelta, date


class Stock_Logic():

    def __init__(self):
        super().__init__()

        self.yesterdays_date = str(date.today() - timedelta(1))
        self.day_before_yesterdays_date = str(date.today() - timedelta(2))
        self.url = 'https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol=TSLA&apikey=43KL8ZSKB1C90DV2'
        self.r = requests.get(self.url)
        data = self.r.json()
        self.stock_close_day_before_yesterday = float(
            data["Time Series (Daily)"][self.day_before_yesterdays_date]["4. close"])
        self.stock_close_yesterday = float(data["Time Series (Daily)"][self.yesterdays_date]["4. close"])
        self.percentage = 0

    def percentage_calc(self):

        if self.stock_close_yesterday > self.stock_close_day_before_yesterday:
            self.percentage = self.stock_close_yesterday / self.stock_close_day_before_yesterday

        elif self.stock_close_day_before_yesterday > self.stock_close_yesterday:
            self.percentage = self.stock_close_day_before_yesterday / self.stock_close_yesterday
